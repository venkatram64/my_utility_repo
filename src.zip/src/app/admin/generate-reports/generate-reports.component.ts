import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generate-reports',
  templateUrl: './generate-reports.component.html',
  styleUrls: ['./generate-reports.component.css']
})
export class GenerateReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
