import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unlock',
  templateUrl: './unlock.component.html',
  styleUrls: ['./unlock.component.css']
})
export class UnlockComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
