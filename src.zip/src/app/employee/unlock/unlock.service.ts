import { Injectable } from '@angular/core';
import { UnlockComponent } from './unlock.component';

@Injectable({
  providedIn: UnlockComponent,
})
export class UnlockService {
}
