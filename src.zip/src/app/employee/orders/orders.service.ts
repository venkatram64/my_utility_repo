import { Injectable } from '@angular/core';
import { OrdersComponent } from './orders.component';

@Injectable({
  providedIn: OrdersComponent,
})
export class OrdersService {
}
