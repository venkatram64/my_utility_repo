import { Injectable } from '@angular/core';
import { EditComponent } from './edit.component';

@Injectable({
  providedIn: EditComponent,
})
export class EditService {
}
