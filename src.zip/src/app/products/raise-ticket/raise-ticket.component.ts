import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raise-ticket',
  templateUrl: './raise-ticket.component.html',
  styleUrls: ['./raise-ticket.component.css']
})
export class RaiseTicketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
