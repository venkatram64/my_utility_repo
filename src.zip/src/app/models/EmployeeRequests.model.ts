
export interface EmployeeRequests {
  _id: string,
  username: string,
  description: Date,
  status: string
}
