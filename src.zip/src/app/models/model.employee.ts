export class Employee {
  constructor(public _id: number, public username: string, public userId: string, public password: string) { }
}
