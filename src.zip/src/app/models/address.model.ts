export interface Address{
    street:string,
    Apt:string,
    city:string,
    state:string,
    zipcode:number
}
