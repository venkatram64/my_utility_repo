import { Product } from "./Product.model";

export interface OrderItem{
  product : Product,
  Quantity: number
}
