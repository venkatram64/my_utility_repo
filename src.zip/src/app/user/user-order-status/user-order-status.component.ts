import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-order-status',
  templateUrl: './user-order-status.component.html',
  styleUrls: ['./user-order-status.component.css']
})
export class UserOrderStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
