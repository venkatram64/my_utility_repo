import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-cort',
  templateUrl: './add-cort.component.html',
  styleUrls: ['./add-cort.component.css']
})
export class AddCortComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


}
